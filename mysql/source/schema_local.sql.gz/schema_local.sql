-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: travelix
-- ------------------------------------------------------
-- Server version	5.7.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migration_versions` (
  `version` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migration_versions`
--

LOCK TABLES `migration_versions` WRITE;
/*!40000 ALTER TABLE `migration_versions` DISABLE KEYS */;
INSERT INTO `migration_versions` VALUES ('20190719080910','2019-07-28 08:56:00'),('20190722134823','2019-07-28 08:56:01'),('20191028080813','2019-11-06 12:38:27'),('20191116132805','2019-11-16 13:29:15'),('20191117105134','2019-11-18 07:56:07'),('20191117105657','2019-11-18 07:56:07'),('20191117112222','2019-11-18 07:56:08'),('20191118192019','2019-11-19 07:07:37'),('20191119102017','2019-11-19 10:20:27'),('20191119104551','2019-11-19 10:45:56'),('20191119205652','2019-11-20 08:02:52'),('20191212114443','2019-12-12 11:44:54'),('20191217134332','2019-12-17 13:44:28'),('20191217192300','2019-12-18 07:25:04'),('20191226131256','2019-12-26 13:13:42');
/*!40000 ALTER TABLE `migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_context`
--

DROP TABLE IF EXISTS `user_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_context` (
  `id` bigint(20) NOT NULL COMMENT '(DC2Type:users:user_context_item_id)',
  `user_login` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:users:user_login)',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BA509B7448CA3048` (`user_login`),
  CONSTRAINT `FK_BA509B7448CA3048` FOREIGN KEY (`user_login`) REFERENCES `users` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_context`
--

LOCK TABLES `user_context` WRITE;
/*!40000 ALTER TABLE `user_context` DISABLE KEYS */;
INSERT INTO `user_context` VALUES (1165315058436216679,'shoutouts__people','has_requested_become_pro_travel','true');
/*!40000 ALTER TABLE `user_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verified` double NOT NULL,
  `active` double NOT NULL,
  `created` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `user_lang` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_id` bigint(20) NOT NULL COMMENT '(DC2Type:users:user_external_id)',
  `business_card` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:users:user_login)',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documents` json DEFAULT NULL COMMENT '(DC2Type:json_array)',
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('Alex Travelguy','allmarkeloff@gmail.com','stub',0,1,'2019-11-20 03:43:25','en','pro_traveler',182247888,'Just a traveler and GoPro abuser\nCrete ?? next\nCurrently trying to build travel hiking community. ?\nMore info here:','2019-12-24 08:27:21',NULL,NULL,NULL,'shoutouts__people','','[]');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_route_bookings`
--

DROP TABLE IF EXISTS `users_route_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_route_bookings` (
  `id` bigint(20) NOT NULL COMMENT '(DC2Type:users:route_booking_id)',
  `user_login` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:users:user_login)',
  `date_index` int(11) NOT NULL,
  `route_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FA11EDAB48CA3048` (`user_login`),
  CONSTRAINT `FK_FA11EDAB48CA3048` FOREIGN KEY (`user_login`) REFERENCES `users` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_route_bookings`
--

LOCK TABLES `users_route_bookings` WRITE;
/*!40000 ALTER TABLE `users_route_bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_route_bookings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-26 15:43:52
